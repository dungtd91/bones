# SiteOrigin Widgets Bundle

Welcome to the development page for the SiteOrigin widgets bundle. We created this bundle primarily for you to use with your [Page Builder](https://siteorigin.com/page-builder/) pages.

## Contributing

We welcome issue reports and pull requests. If you're familiar with how the widget bundle works, you can even submit entire widgets.

## Support

You can get support for the widgets bundle on the [SiteOrigin support forums](https://siteorigin.com/thread/).